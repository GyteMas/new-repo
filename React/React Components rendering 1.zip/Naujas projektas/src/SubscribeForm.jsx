function SubscribeForm() {

  return (
    
<div className="bg-cyan-200 p-5 w-[96%] text-center mx-auto rounded-xl m-5">
  <h1 className="font-semibold text-2xl uppercase">Subscribe</h1>
  <p className="text-center p-8">Sign up with your email address to receive news and updates.</p>
  <form>
    <div className="flex gap-3 justify-center">
    <input className="p-2 rounded-lg" type="text" placeholder="First name"/>
    <input className="p-2 rounded-lg" type="text" placeholder="Last name"/>
    <input className="p-2 rounded-lg" type="text" placeholder="Email"/><br/>
    </div>
    <button className="bg-red-400 text-white py-2 w-80 my-5 rounded-lg" type="submit">Submit</button></form>
</div>
   
  )
}
export default SubscribeForm;