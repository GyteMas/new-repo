import SubscribeForm from "./SubscribeForm.jsx";
function App() {
  
  const array = [];
  for (let i = 0; i < 5; i++) {
    array.push(<SubscribeForm/>);
  }
  
  return array;
}
export default App;
