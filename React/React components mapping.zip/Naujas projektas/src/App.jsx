import PictureArray from "./pictureArray";

function App() {
  return (
    <>
      <PictureArray />
    </>
  );
}
export default App;
