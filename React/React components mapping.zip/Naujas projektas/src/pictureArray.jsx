function PictureArray() {
  const images = [
    "src/assets/150-1505926_javascript-logo-png-javascript-logo-transparent-png.png",
    "src/assets/1532556.png",
    "src/assets/background-image-transparency-css-clipart.jpg",
    "src/assets/react.png"
  ];
  return (
    <div className="grid grid-cols-4">
      {images.map((url) => (
        <img src={url} key={Math.random()} />
      ))}
    </div>
  );
}
export default PictureArray;
