import './Info.css';

function Info({followers, views, likes}) {
    return (
        <>
            <section id="navBar">
                <div className="container">
                    <p>Followers</p>
                    {followers}
                </div>
                <div className="container">
                    <p>Views</p>
                    {views}
                </div>
                <div className="container">
                    <p>Likes</p>
                    {likes}
                </div>
            </section>
        </>
    )
}

export default Info;