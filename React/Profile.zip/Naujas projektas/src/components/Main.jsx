import './Main.css';
import Profile from './Profile.jsx';
import Info from './Info.jsx';
import user from '../assets/user.js';

function Main() {

    const {username, tag, location, avatar, stats: {followers, views, likes}} = user;


    return (
        <>
            <div id='main'>
                <Profile
                    avatar={avatar}
                    username={username}
                    tag={tag}
                    location={location}
                />
                <Info
                    followers={followers}
                    views={views}
                    likes={likes}
                />
            </div>
        </>
    )
}

export default Main;