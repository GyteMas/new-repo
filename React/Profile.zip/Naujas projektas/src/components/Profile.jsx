import './Profile.css';

function Profile({avatar, username, tag, location}) {
    return (
        <>
            <div className="container">
                <img src={avatar} alt="" id="avatar"/>
                <h1>{username}</h1>
                <h2>@{tag}</h2>
                <h3>{location}</h3>
            </div>
        </>
    )
}

export default Profile;