import Main from './components/Main.jsx'

function App() {
  return (
    <>
      <Main/>
    </>
  )
}

export default App
