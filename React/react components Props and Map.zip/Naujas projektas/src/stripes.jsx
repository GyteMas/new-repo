function Stripes({ hexaColor }) {
  const colors = [];

  for (let i = 0; i < 5; i++) {
    colors.push(hexaColor());
  }
  return (
    <div>
      {colors.map((color, index) => {
        console.log(index);

        return (
          <div className="p-10 w-[400px] text-center font-bold" style={{backgroundColor: `${color}`}} key={index}>
            {color}
          </div>
        );
      })}
    </div>
  );
}

export default Stripes;
