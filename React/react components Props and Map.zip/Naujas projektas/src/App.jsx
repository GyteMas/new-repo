import Stripes from "./stripes";
import hexaColor from "./color_generator";

function App() {
  return (
    <>
      <Stripes hexaColor={hexaColor} />
      <br />
      <hr />
    </>
  );
}
export default App;
