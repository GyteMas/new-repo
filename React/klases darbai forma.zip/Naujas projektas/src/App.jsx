import ControlledComp1 from "./components/ControlledComp1"
import ControlledComp2 from "./components/ControlledComp2"
import ControlledComp3 from "./components/ControlledComp3"
import RegexCheck from "./components/ControlledComp4";
import EmailValidationForm from "./components/ControlledComp5";
function App() {
  return (
    <>
      <ControlledComp1/>
      <ControlledComp2/>
      <ControlledComp3/>
      <RegexCheck/>
      <EmailValidationForm/>
    </>
  );
}
export default App;
