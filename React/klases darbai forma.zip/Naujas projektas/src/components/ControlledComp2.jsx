import { useState } from "react";

function ControlledComp2() {
  const [inputValue, setInputValue] = useState("");
  
  const handleChange = (event) => {
    setInputValue(event.target.value);

  };
  const arr =[]

  for (let i = 1; i <= 5; i++) {
    arr.push(<div key={i}><label htmlFor={"Radio" +i}>Radio {i}:</label><input
      type="radio"
      name={"Radio"}
      id={"Radio" +i}
      className="form-input"
      onChange={handleChange}
      value={"Radio" +i}
    /></div>)

  
  }
  return (
    <> {arr} {inputValue}
    </>
  )
}

export default ControlledComp2;
