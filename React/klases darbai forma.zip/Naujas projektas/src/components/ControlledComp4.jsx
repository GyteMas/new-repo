import { useState } from "react";
 
const RegexCheck = () => {
    const [email, setEmail] = useState("");
    const [error, setError] = useState("");
 
    const isValidEmail = (email) => {
        const emailRegex = /^[a-zA-Z0-9._:$!%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailRegex.test(email)) {
          throw new Error("Your are duck and dont know your email :)");
        }
      };
    
      const handleSubmit = (e) => {
        e.preventDefault(); // Prevent the default form submission
         try {
          isValidEmail(email); // Validate email
          setError(""); // Clear any previous errors
          alert("Hoop hoop hooray! You  manage o get email right! :)");
         } catch (err) {
          setError(err.message); // Set the error message
        }
      };
    
      return (
        <form onSubmit={handleSubmit}>
          <label>Email:</label>
          <input
            type="text"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <button type="submit">Submit</button>
          {error && <p style={{ color: "red" }}>{error}</p>}
        </form>
      );
}
 
export default RegexCheck;