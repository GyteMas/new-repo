import { useState } from "react";
const VerEmailPass = () => {
 
const[email,setEmail] = useState("")
const[password,setPassword] = useState("")
const[error,setError] = useState("")
 
const validateEmail = (email) => {
    const RegExp = /^[a-zA-Z0-9._:$!%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!RegExp.test(email)) {
        throw new Error("Invalid Email or Password")
    }
}
 
const validatePassword = (password) => {
    const RegExp = /^(?=.*?[A-Za-z])(?=.*?[0-9])(?=.*?[-+_!@#$%^&*.,?]).{8,}$/
    if(!RegExp.test(password)) {
        throw new Error ("Invalid Email or Password")
    }
}
 const handleSubmit = (e) =>{
    e.preventDefault();
    try{
        validateEmail(email);
         validatePassword(password);
        setError("")
        alert("Email and Password successfully submitted")
    } catch (err) {
        setError(err.message)
 
    }
 }
 
 
 
    return (
        <form onSubmit={handleSubmit}>
        <label>
          Email:
          <input
            type="text"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </label>
        <label>
          Password:
          <input
            type="text"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
       
        <button type="submit">Submit</button>
        {error && <p style={{ color: "red" }}>{error}</p>}
      </form>
     );
}
 
export default VerEmailPass;