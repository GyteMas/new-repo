import { useState } from "react";
function CountClicks() {
  //const users = {name: "Nameless, isLoggedIn: true"}
  const [count, setCount] = useState(0);
  const increase = () => setCount((prev) => prev+3);
  const decrease = () => setCount((prev) => prev-5);
  return (
    <>
      <div>{count}</div>
      <button className="border-2 border-black px-3" onClick={increase}>Increase 3</button>
      <button className="border-2 border-black px-3" onClick={decrease}>Decrease 5</button>
    </>
  );
}
export default CountClicks;
