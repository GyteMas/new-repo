import Header from "./header";

function App() {
  const data= [
    {img:'./../public/assets/vector-digital-print-logo-design.jpg', title: "Title 1", descr:"Lorem1"},
    {img:'./../public/assets/vector-digital-print-logo-design.jpg', title: "Title 2", descr:"Lorem2"},
    {img:'./../public/assets/vector-digital-print-logo-design.jpg', title: "Title 3", descr:"Lorem3"},
  ]
  return (
    <>
    <div className="flex flex-col-3 text-center">
      <Header img = {data[0].img} title={data[0].title} description={data[0].descr}/>
      <Header img = {data[1].img} title={data[1].title} description={data[1].descr}/>
      <Header img = {data[2].img} title={data[2].title} description={data[2].descr}/>
      </div>
    </>
  );
}
export default App;
