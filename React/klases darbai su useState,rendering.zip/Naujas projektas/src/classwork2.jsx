import { useState } from "react";
function CountClicks() {
  //const users = {name: "Nameless, isLoggedIn: true"}
  const [items, setItem] = useState([]);
  const addItem = () => {
    const newItem = `Item ${items.length + 1}`;
    setItem([...items, newItem]);
  };

  const removeItem = (itemIndex) => {
    const filteredArray = items.filter((item, index) => index !== itemIndex);
    setItem(filteredArray);
  };
  return (
    <>
      {items.map((item, index) => (
        <div key={index}>
          <p>{item}</p>
          <button className="border-2 border-black px-3" onClick={()=>removeItem(index)}>
            Remove Item
          </button>
        </div>
      ))}
      <button className="border-2 border-black px-3" onClick={addItem}>
        Add Item
      </button>
    </>
  );
}
export default CountClicks;
