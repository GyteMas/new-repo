function Header(props) {
    console.log(props);
    
  return (
    <div>
        <img className="w-[200px] h-[200px]" src={props.img} alt="" />
      <h1>{props.title}</h1>
      <p>
        {props.description}
      </p>
    </div>
  );
}

export default Header;
