import { useState } from "react";
function Cards({ robot }) {
  const [reserved, setIsReserved] = useState(false);

  const handleClick = () => {
    setIsReserved((current) => !current);
  };
  return (
    <>
      <div
        className={
          "bg-lime-400 p-2 grid place-content-center " +
          (reserved ? "grayscale" : "")
        }
      >
        <img className="" src={robot.avatar} alt="" />
        <p className="pt-2 font-semibold text-center">{robot.name}</p>
        <p className="text-center pb-2">{robot.email}</p>
        <div className="grid place-content-center">
          {reserved ? (
            <p className="font-semibold">Reserved</p>
          ) : (
            <button
              className="bg-purple-400 px-4 text-center"
              onClick={handleClick}
            >
              Reserve
            </button>
          )}
        </div>
      </div>
    </>
  );
}
export default Cards;
