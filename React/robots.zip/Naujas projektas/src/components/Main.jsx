import { useState } from "react";
import { robots } from "/src/data/robots";
import Cards from "./Cards";

function Main() {
  const [searchItem, setSearchItem] = useState("");
  const [filteredRobots, setFilteredRobots] = useState(robots);

  const handleInputChange = (e) => {
    const searchTerm = e.target.value;
    setSearchItem(searchTerm);

    const filteredRobots = robots.filter((robot) =>
      robot.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    setFilteredRobots(filteredRobots);
  };

  return (
    <>
     <section className="flex flex-col w-[full] justify-center place-items-center">
        <h1 className="text-center text-4xl font-semibold p-3">RoboFriends</h1>
        <input
          className="text-center w-[40vh]"
          type="text"
          value={searchItem}
          onChange={handleInputChange}
          placeholder="Type to search"
        />
      </section>
      <hr className="border-black bg-black p-1 mb-1" />



      <section className="grid grid-cols w-[full] gap-4 mx-5 md:w-[70vw] md:grid-cols-3">
        {filteredRobots.map((robot, index) => {
          return (
            <Cards key={index} robot={robot}/>
          );
        })}
      </section>
    </>
  );
}

export default Main;
