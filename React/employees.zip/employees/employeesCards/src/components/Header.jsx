function Header() {
  return (
    <div className= "p-5 text-white header">
      <h1 className="display-1">Employees</h1>
    </div>
  );
}

export default Header;
