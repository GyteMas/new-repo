function Header() {
  return (
    <div
      className="md:w-[70vw] h-[20vh] w-[100vw] flex flex-col justify-center ??????"
      style={{
        backgroundImage: `url("/images/FlightAware.jpg")`}}
    >
      <h1 className="font-semibold text-4xl text-center text-white p-3">
        30 Days Of React
      </h1>
      <h2 className="text-3xl text-center  text-white pb-2">
        World population
      </h2>
      <h6 className="text-center text-xs  text-white pb-2">
        Ten most populated countries
      </h6>
    </div>
  );
}
export default Header;
