import { tenHighestPopulation } from "../data/ten_most_highest_populations";
import Country from "./Country";
function Cards() {
  return (
    <section className="grid grid-cols-4 md:w-[70vw] h-[20vh] w-[full]">
      {tenHighestPopulation
        .sort((a, b) => b.population - a.population)
        .map((country, index) => {
          const calculation = Math.round(
            (country.population / tenHighestPopulation[0].population) * 100
          );

          return (
            <Country key={index} country={country} calc={calculation}/>
          );
        })}
    </section>
  );
}
export default Cards;
