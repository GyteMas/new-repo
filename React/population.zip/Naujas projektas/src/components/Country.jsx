function Country({ country, calc }) {
  return (
    <>
      <div className="uppercase font-semibold m-2 col-span-1 text-center">
        {country.country}
      </div>
      <div
        className="uppercase font-semibold m-2 col-span-2 bg-emerald-700 h-6"
        style={{
          width: `${calc}%`,
        }}
      >
        {calc}
      </div>
      <div className="uppercase font-semibold m-2 col-span-1 text-center">
        {country.population}
      </div>
    </>
  );
}
export default Country;
