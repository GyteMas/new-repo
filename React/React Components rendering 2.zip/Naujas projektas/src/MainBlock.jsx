import MainBlockPart1 from "./MainBlockPart1.jsx";
import MainBlockPart2 from "./MainBlockPart2.jsx";
function MainBlock() {
  return (
    <>
      <MainBlockPart1 />
      <MainBlockPart2 />
    </>
  );
}
export default MainBlock;
