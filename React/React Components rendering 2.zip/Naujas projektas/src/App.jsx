import Header from "./Header.jsx";
import MainBlock from "./MainBlock.jsx";
import Footer from "./Footer.jsx";
function App() {
  return (
    <>
  <Header />
  <MainBlock />
  <Footer />
  </>
)
}
export default App;
 