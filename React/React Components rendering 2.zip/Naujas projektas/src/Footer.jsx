function Footer() {

  return (
    
<div className="bg-cyan-200 p-5 w-[full] mx-auto">
  <h1 className="font-normal text-sm px-16 text-center">Copyright &copy; 2020</h1>
</div>
   
  )
}
export default Footer;