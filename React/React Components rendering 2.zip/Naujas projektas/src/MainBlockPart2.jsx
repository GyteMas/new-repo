function MainBlockPart2() {

  return (
    
<div className="px-10 py-0 w-[full] mx-auto">
  <img className="mx-16 w-[200px] h-[200px] rounded-full object-cover" src="/public/assets/DMU-Dr-Pravin-Mishra-headshot-2023_1-400x400-square-1198f0ae255dce3501b59ae0e0914aa2-5ba4f67d9b16b.jpg" alt="" />
  <p className="mb-10 mx-16 text-xl">Asabeneh Yetayeh</p>
</div>
   
  )
}
export default MainBlockPart2;