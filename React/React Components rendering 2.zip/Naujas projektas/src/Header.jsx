function Header() {

  return (
    
<div className="bg-cyan-200 p-5 w-[full] mx-auto">
  <h1 className="font-normal text-4xl px-16">Welcome to 30 Days Of React</h1>
  <p className="px-16 pt-5 text-xl">Getting Started React</p>
  <p className="px-16 text-lg">Javascript Library</p>
  <p className="px-16 text-sm">Asabeneh Yetayeh</p>
  <p className="px-16 text-xs">Oct 3, 2020</p>
</div>
   
  )
}
export default Header;