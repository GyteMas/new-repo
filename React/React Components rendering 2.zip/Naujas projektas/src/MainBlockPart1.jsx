function MainBlockPart1() {

  return (
    
<div className="p-10 w-[full] mx-auto">
  <p className="px-16 text-sm">Prerequisite to get started <span className="font-bold italic">react.js:</span></p>
  <p className="px-16 text-sm">HTML</p>
  <p className="px-16 text-sm">CSS</p>
  <p className="px-16 text-sm">JavaScript</p>
  <p className="px-16 text-sm">3+2=5</p>
  <p className="px-16 text-sm">I am Asabeneh Yetayeh. I am 200 years old. I love React and thank you for joining 30 Days Of Reach challenge.</p>
</div>
   
  )
}
export default MainBlockPart1;