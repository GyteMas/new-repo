function Mapping() {
  const calendar = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
 
  function isPrime(item) {
    if (item <= 1) return false;
    for (let i = 2; i <= Math.sqrt(item); i++) {
      if (item % i === 0) return false;
    }
    return true;
  }

  return (
    <div className="grid grid-cols-8 justify-center">
      {calendar.map((item, index) => {
  return (
          <>
            <div
              className={`${isPrime(item) ? 'bg-red-500':item % 2 ===0 ? 'bg-green-500': 'bg-yellow-500'} w-32 h-32 border-2 border-white text-center place-content-center text-3xl text-white`}
              key={index}
            >
              {item}
            </div>
          </>
        );
      })}
    </div>
  );
}
export default Mapping;
