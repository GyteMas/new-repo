import Mapping from "./Mapping";


function App() {
  return (
    <>
  <Mapping/><br/><hr/>
    </>
  );
}
export default App;
