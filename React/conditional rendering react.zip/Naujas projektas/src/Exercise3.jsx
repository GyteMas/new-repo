import { useState } from "react";
function Basic_3() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const logIn = () => setIsLoggedIn((prev) => !prev);

  let jsx;
  let text;
  if (isLoggedIn) {
    text = <p>You are logged in</p>
    jsx = <button className="border-2 border-black px-3" onClick={logIn}>Profile</button>;
  } else {
    text = <p>You are not logged in, please log in or sign up</p>
    jsx = <div><button className="border-2 border-black px-3" onClick={logIn}>Log in</button><button className="border-2 border-black px-3" onClick={logIn}>Sign up</button></div>;
  }
  return (
    <>
    <div>{text}</div>
      <div>{jsx}</div>
    </>
  );
}
export default Basic_3;
