import { useState } from 'react';

const Exercise9 = () => {
  const [activeTab, setActiveTab] = useState(0);

  const tabs = [
    { title: 'Home', content: 'Welcome to Home' },
    { title: 'Profile', content: 'Welcome to Profile' },
    { title: 'Settings', content: 'Welcome to Settings' },
  ];
  return (
    <div>
      <div className="tab-buttons">
        {tabs.map((tab, index) => (
          <button
            key={index}
            className={`bg-orange-500 w-16${activeTab === index ? 'active' : ''}`}
            onClick={() => setActiveTab(index)}
          >
            {tab.title}
          </button>
        ))}
      </div>
      <div className="tab-content">
        {tabs[activeTab].content}
      </div>
    </div>
  );
};

export default Exercise9;
