const Exercise10 = () => {
  const featureFlags = [
    { title: "blabla1", newFeature: true },
    { title: "blabla2", deprecatedFeature: true },
    { title: "blabla3", newFeature: true },
    { title: "blabla4", deprecatedFeature: false },
  ];
  return (
    <div>
      {featureFlags.map((feature, index) => {
        return (
          <>
            {/* <div className={`bg-orange-500 ${feature.deprecatedFeature  ? 'hidden' : ''}`} key={index}>
            {feature.title}
            {feature.newFeature&&<p className="font-bold">New</p>}
          </div> */}

            {!feature.deprecatedFeature && (
              <div className="bg-orange-500" key={index}>
                {feature.title}
                {feature.newFeature && <p className="font-bold">New</p>}
              </div>
            )}
          </>
        );
      })}
    </div>
  );
};

export default Exercise10;
