import { useState } from "react";

function Exercise8(){
const [isOpen, setIsOpen] = useState("false");

  const toggleOpening = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div>
      <button className="bg-orange-500" onClick={toggleOpening}>
        {isOpen ? 'Hide' : 'Show'} Element
      </button>
      {isOpen && <div>This is a toggled element.</div>}
    </div>
  );
};

export default Exercise8;
