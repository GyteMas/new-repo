import { useState } from "react";

function Exercise7(){
  const [userType, setUserType] = useState("student");
  return(
    <form>
      <label htmlFor="tipas">Pasirinkite tipa</label>
      <br />
      <select id="tipas" onChange={(e) => setUserType(e.target.value)}>
        <option value="student">Studentas</option>
        <option value="teacher">Mokytojas</option>
      </select>
      {userType === "student"?(
      <>
        <label htmlFor="grade">Pažymys</label>
        <input type="number" id="grade" />
      </>
      ):(
      <>
        <label htmlFor="subject">Tema</label>
        <input type="text" id="subject" />
      </>
      )}
    </form>
  )
}
export default Exercise7;
