import { useState } from "react";
function Basic_1() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const logIn = () => setIsLoggedIn((prev) => !prev);

  let jsx;
  if (isLoggedIn) {
    jsx = <p>Welcome, User!</p>;
  } else {
    jsx = <p>Please log in</p>;
  }
  return (
    <>
      <div>{jsx}</div>
      <button className="border-2 border-black px-3" onClick={logIn}>Login</button>
    </>
  );
}
export default Basic_1;
