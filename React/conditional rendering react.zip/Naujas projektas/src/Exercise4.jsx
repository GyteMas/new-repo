const Greeting = () => {

  const userType = "user";

  switch (userType) {
    case "admin":
      return <div>
        <h1>Welcome admin</h1>
        <p>this is your AdminPanel</p>
      </div>;
    case "user":
      return <div>
      <h1>Welcome user</h1>
      <p>this is your UserDashboard</p>
    </div>;
    default:
      return <div>
      <h1>Welcome guest</h1>
      <p>this is your GuestPage</p>
    </div>;
  }
};
export default Greeting;