import { useState } from "react";
function Task() {
  const [tasks, setItem] = useState([]);
  const addItem = () => {
    const newTask = `Item ${tasks.length + 1}`;
    setItem([...tasks, newTask]);
  };

  const removeItem = (taskIndex) => {
    const filteredArray = tasks.filter((task, index) => index !== taskIndex);
    setItem(filteredArray);
  };
if (tasks.length !== 0) {
  return (
    <>
      {tasks.map((task, index) => (
        <div key={index}>
          <p>{task}</p>
          <button className="border-2 border-black px-3" onClick={()=>removeItem(index)}>
            Remove Task
          </button>
        </div>
      ))}
      <button className="border-2 border-black px-3" onClick={addItem}>
        Add Task
      </button>
    </>
  );
} else{
  return (<><p>No tasks available</p><button className="border-2 border-black px-3" onClick={addItem}>
    Add Task
  </button></>)
}
}
export default Task;