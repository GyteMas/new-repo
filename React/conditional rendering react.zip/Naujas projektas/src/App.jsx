import Basic_1 from "./Exercise1";
import Basic_2 from "./Exercise2";
import Basic_3 from "./Exercise3";
import Greeting from "./Exercise4";
import Task from "./Exercise5";
import Notification from "./Exercise6";
import Exercise7 from "./Exercise7";
import Exercise8 from "./Exercise8";
import Exercise9 from "./Exercise9";
import Exercise10 from "./Exercise10";

function App() {
  return (
    <>
  {/* <Basic_1/><br/><hr/>
  <Basic_2/><br/><hr/>
  <Basic_3/><br/><hr/>
  <Greeting/><br/><hr/>
  <Task/><br/><hr/>
  <Notification/><br/><hr/>
  <Exercise7/><br/><hr/>
  <Exercise8/><br/><hr/>
  <Exercise9/><br/><hr/> */}
  <Exercise10/><br/><hr/>
    </>
  );
}
export default App;
