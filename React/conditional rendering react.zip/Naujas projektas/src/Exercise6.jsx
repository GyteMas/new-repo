const Notification = () => {

  const noticeType = "error";

  switch (noticeType) {
    case "success":
      return <div className="w-[100px] h-[100px] bg-green-500">
        <h1>Success</h1></div>;
    case "error":
      return <div className="w-[100px] h-[100px] bg-red-500">
      <h1>Error</h1></div>;
    default:
      return <div className="w-[100px] h-[100px] bg-yellow-400">
      <h1>Warning</h1></div>;
  }
};
export default Notification;